# CleanAbricate

This code was created July 26, 2019- August 1, 2019 at the Utah Public Health Laboratory
@ElizabethCook21

You'll have to use this code on a linux machine
It is designed to clean abricate results, use BedTools to merge plasmid results, then do more quality controls.
The output is an edited abricate file with just relevant plasmids (%coverage larger than 65%) and a final list of plasmids that are greater than 65%
